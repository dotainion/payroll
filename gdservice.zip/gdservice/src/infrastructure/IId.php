<?php
namespace src\infrastructure;

interface IId{
    public function toString():string;
}