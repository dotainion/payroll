<?php
namespace src\infrastructure;

interface IAction{
    public function execute();
}