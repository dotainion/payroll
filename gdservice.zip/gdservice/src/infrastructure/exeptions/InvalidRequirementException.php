<?php
namespace src\infrastructure\exeptions;

use InvalidArgumentException;

class InvalidRequirementException extends InvalidArgumentException{

}