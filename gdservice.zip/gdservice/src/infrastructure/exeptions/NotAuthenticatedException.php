<?php
namespace src\infrastructure\exeptions;

use Exception;

class NotAuthenticatedException extends Exception{

}