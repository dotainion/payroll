<?php
namespace src\infrastructure\exeptions;

use Exception;

class TokenExpiredException extends Exception{

}