<?php
namespace src\module\login\objects;

use src\infrastructure\ICredential;
use src\security\Security;

class Credential extends Security implements ICredential{

}